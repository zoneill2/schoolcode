public class Dec6two
{

public static void main (String [] args)
{
int [] array = new int [100]

for (i=0; i<100; i++)
{
int x = int
}
}












}