import java.util.*;

public class MazeRunner {
   public static void main (String[] arg) {
   

   

}