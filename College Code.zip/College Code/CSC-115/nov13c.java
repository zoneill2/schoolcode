import java.math.BigDecimal;
public class nov13c

{

public static void main (String [] args)
{
int bob = 9;
double alice = bob;


System.out.println(bob);
System.out.println(alice);

double sneeze = 9;
int cough =  (int) sneeze;

double alex = 13.8;
//System.out.println(alex);
int cody = (int) Math.round(alex);
System.out.println(cody);




}

















}