import java.math.BigDecimal;
public class nov13b

{

public static void main (String [] args)
{


System.out.println(4/2);
System.out.println(8/3);
System.out.println(8.0/3.0);


}

















}