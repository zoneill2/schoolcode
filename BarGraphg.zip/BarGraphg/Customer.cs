﻿using System;

public class Customer
{
	public string name;
	public int money;

	public Customer(string n,int m)
	{
		name = n;
		money = m;
	}
}
