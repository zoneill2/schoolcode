import java.util.Scanner;


public class oct9
{
   public static void main (String [] args)
   {
 
   String name;
   String initial;
   int nameLength;
   String lastLetter;
   
   Scanner in = new Scanner (System.in);
   System.out.print("Whats your first name? ");
   name = in.next();
   //initial = name.substring(0,1);
   nameLength = name.length();
  // System.out.println("Why hello there " + initial + "!");
   System.out.println("Your name has " + nameLength + " characters in it.");
   
   
   //if (initial.equalsIgnoreCase("A") || initial.equalsIgnoreCase("E") || initial.equalsIgnoreCase("I") || initial.equalsIgnoreCase("O") || initial.equalsIgnoreCase("U") )
      {
      System.out.println("Wow a vowel!");
      }
      
  // else
      {
      System.out.println("Wow...a consonant....");
      }

   
   lastLetter = name.substring(nameLength-1, (nameLength));
   System.out.println("Wow the last letter of your name is " + lastLetter + "!");






























   }








}



















