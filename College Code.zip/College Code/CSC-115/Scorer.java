public class Scorer
{

public static void main (String [] args)
{

System.out.print("Enter Team 1's Name");
String team1 = next.String();









}





























}