import java.util.Scanner;
import java.util.Random;


public class oct9two
{
   public static void main (String [] args)
   {
      
    int daNumba;
    int daNumba2;
    int daNumbas;
   
    Scanner in = new Scanner (System.in);
    Random myRand = new Random ();
    daNumba = 1 + myRand.nextInt(6);
    daNumba2 = 1 + myRand. nextInt(6);
    System.out.println(daNumba);
    System.out.println(daNumba2);
    daNumbas = daNumba + daNumba2;
    
    if ( daNumbas == 7 || daNumbas == 11)
       {
       System.out.println("Winner!!");
       }
       
    else if (daNumbas == 2 || daNumbas == 3 || daNumbas == 13)
       {
       System.out.println("Loser!!");
       }
       
    else
       {
       System.out.println("Roll Again!!");
       }




























   }








}



















