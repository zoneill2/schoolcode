public class nov8
{
public static double goBob(double numba, String numba2)
{
return numba;

}




public static void main (String [] args)
{
System.out.println(goBob(1, "hi"));

}







}