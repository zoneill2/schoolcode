import java.util.Scanner;


public class oct23
{
   public static void main (String [] args)
   {
    
   scanner in = new Scanner (System.in);
   System.out.println("wow");






















   }








}



















