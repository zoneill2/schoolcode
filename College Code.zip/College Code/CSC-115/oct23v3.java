import java.util.Scanner;
import java.util.Random;

public class HighLowGame

{
   public static void main (String [] args)
   {
   int magicNumber;
   int guess;
   int guessNum = 0;
   
    
   Scanner in = new Scanner (System.in);
   Random myRand = new Random ();
   magicNumber = 1 + myRand.nextInt(100);
   System.out.print("Guess a number 1-100 ");
   guess = in.nextInt();
   
   while (guess != magicNumber )
   {
      if (guess < magicNumber)
      {
      System.out.println("Higher!");
      guessNum = guessNum + 1;
      }
      
  
      else if (guess > magicNumber)
      {
      System.out.println("Lower!");
      guessNum = guessNum + 1;
      }
   
      else if (guess == magicNumber)
      {
      System.out.println("Winner Winner!");
      }
      
   
      else 
      {
      System.out.println("Please enter a valid number!");
      }
   
   }


















   }








}



















