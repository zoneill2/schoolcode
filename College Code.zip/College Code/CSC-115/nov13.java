import java.math.BigDecimal;
public class nov13

{

public static void main (String [] args)
{


System.out.println(4.35*99);
System.out.println(4.35*100);
BigDecimal numba1 = new BigDecimal("4.35");
BigDecimal numba2 = new BigDecimal("100");

System.out.println(numba1.multiply(numba2));






}

















}