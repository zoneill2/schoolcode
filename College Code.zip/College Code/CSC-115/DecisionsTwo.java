import java.util.Scanner;

public class DecisionsThree
{

   public static void main (String [] args)
  
      {
      double weather;
    
      
      Scanner in = new Scanner (System.in);
      System.out.print("What's today's temperature? ");
      weather = in.nextDouble();
      System.out.println("Today, the temperature is " + weather + "!");
      
      if (weather <= 32 || weather >=212)
         {
         System.out.println("Not Liquid!");
         }
     
      
          
      
      
      
      
      
      
      
      
      
      
      
      }




















}