public class NameinBox
 {
   public static void main (String [] args)
   {
   System.out.println("******");
   System.out.println("*Zach*");
   System.out.println("******");
   }

 }