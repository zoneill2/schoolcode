import java.util.Scanner;

public class DecisionsTwo
{

   public static void main (String [] args)
  
      {
      double avg;
      
      Scanner in = new Scanner (System.in);
      System.out.print("whats your CSC 115 average? ");
      double avg = in.nextDouble();
      System.out.println("Youre average is " + avg);
      
      
     
      
      
      
      
      
      
      
      
      
      
      
      }




















}