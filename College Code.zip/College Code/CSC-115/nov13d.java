import java.math.BigDecimal;
public class challenge1
{



public static int number(int num)
{
if (num == 1)
{
return false;
}


return true;
}






public static void main (String [] args)
{
System.out.print("Give me a number");
int numba = in.nextInt();
number(numba);



}

















}