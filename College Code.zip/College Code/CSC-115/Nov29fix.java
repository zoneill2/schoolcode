public class Nov29fix
{

public static void main (String [] args)
 {
 
 double [] numbaArray = new double[10];
 
 numbaArray[0]=1;
 numbaArray[1]=2;
 numbaArray[2]=3;
 numbaArray[3]=4;
 numbaArray[4]=5;
 numbaArray[5]=6;
 numbaArray[6]=7;
 numbaArray[7]=8;
 numbaArray[8]=9;
 numbaArray[9]=10;

 
 for (int i=0;i<numbaArray.length;i++)
  {
  System.out.println("Position " + (i+1)+ ": " + numbaArray[i]);
  }
  System.out.println();
  //System.out.println(1+Math.random()*10);
  /*
  for (int i = numbaArray.length -1 ; i>0 ; i-- )
   {
   int j = (int) (Math.random() * (i+1));
   double temp = numbaArray[i];
   numbaArray[i] = numbaArray[j];
   numbaArray[j] = temp;
   }  
   
   
   for (int i=0;i<numbaArray.length;i++)
  {
  System.out.println("Position " + (i+1)+ ": " + numbaArray[i]);
  }
  */
  System.out.println();
  
//rotating up
System.out.println("Rotating up!");
 double temp = numbaArray[0];
 for (int i = 1 ; i< numbaArray.length; i++ )
   {
   numbaArray[i-1] = numbaArray[i];
   }  
   numbaArray[numbaArray.length-1] = temp;
   
   for (int i=0;i<numbaArray.length;i++)
  {
  System.out.println("Position " + (i+1)+ ": " + numbaArray[i]);
  }
  System.out.println();

//rotating down

double temp2 = numbaArray[numbaArray.length-1];

 for (int i = numbaArray.length-2 ; i>=0 ; i-- )
   {
   numbaArray[i+1] = numbaArray[i];
   }  
   numbaArray[0] = temp2;
 
  numbaArray[0] = temp;
  
  
  double temp3 = numbaArray[numbaArray.length-1];

System.out.println("Rotating Down!");
 for (int i = numbaArray.length-2 ; i>=0 ; i-- )
   {
   numbaArray[i+1] = numbaArray[i];
   }  
   numbaArray[0] = temp2;
 
  numbaArray[0] = temp;
  
   for (int i=0;i<numbaArray.length;i++)
  {
  System.out.println("Position " + (i+1)+ ": " + numbaArray[i]);
  }
  System.out.println();
  
 } //end main
 } //end class