import java.util.Scanner;
import java.util.Random;

public class Oct25

{
   public static void main (String [] args)
   {
   int random;
   int odd=0;
   int even=0;
   int fifty=1;
   
   
   
    
   Scanner in = new Scanner (System.in);
   Random myRand = new Random ();
   boolean done = false; 
   int loop = 0;
   
   while (!done)
   {
    
   
   
   for (int i=1; i<=100; i++)
   {
  
   random = 1 + myRand.nextInt(100);
       if (random%2==0)
       {
       even++;
   
       }
   
       else
       {
       odd++;
       }
   System.out.printf("%4d", random);
      if (i%10==0)
      {
      System.out.println();
      }
  
   
     
   
   } //end for
   System.out.println("\nYou had " + even + " evens and " + odd + " odds!");
   if (odd==50)
      {
      done=true;
      }
      
      else
      {
      odd = 0;
      even = 0;
      loop++;
      }
      
  }//end while
  
  System.out.println(loop + " tries!");




   } //end main

} //end class



















