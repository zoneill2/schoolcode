public class Oct30c
{


public static void main (String [] args)
{
int sum=0;
int sum2=20;
int sum3=35;

for (int i=1; i<=10; i++) //
   {
  
  sum = sum + i;    
   
   
   }

System.out.println(sum);


for (int i=20; i<=37; i++) //
   {
  
  sum2 = sum2 + i;    
   
   
   }

System.out.println(sum2);



for (int i=35; i<=49; i++) //
   {
  
  sum3 = sum3 + i;    
   
   
   }

System.out.println(sum3);


















}


}