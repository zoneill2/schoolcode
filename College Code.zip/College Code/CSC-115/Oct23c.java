import java.util.Scanner;
import java.util.Random;
public class Oct23c
{
public static void main (String [] args)
   {
   Scanner in = new Scanner (System.in);
   Random myRand = new Random();
   int daNumba = 1 + myRand.nextInt(100);
   System.out.print("Guess a number from 1 to 100: ");
   int daGuess = in.nextInt();
      
   if (daGuess != daNumba)
   {
      if (daGuess < daNumba)
      {
      System.out.println("Too low. Guess higher!");
      }
      else
      {
      System.out.println("Too high. Guess lower!");
      }  
   }
      else
   {
   System.out.println("Winner Winner Chicken Dinner!");
   }
   } //end main   
}//end class 