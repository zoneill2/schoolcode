import java.util.Scanner;


public class oct23
{
   public static void main (String [] args)
   {
   int number;
    
   Scanner in = new Scanner (System.in);
   System.out.print("What is your favorite number? ");
   if (in.hasNextInt()  )
   {
   number = in.nextInt();
   System.out.println(number + " is my favorite number too!");
   }
   
   else
   {
   System.out.println("Please enter a whole number!");
   }





















   }








}



















