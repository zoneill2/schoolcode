import java.util.Scanner;
public class Nov6

{

public static void grader(double average)
{



if (average >= 90)
{
   System.out.println("A");
}

else if (average >= 80)
{
   System.out.println("B");
}

else if (average >= 70)
{
   System.out.println("C");
}

else if (average >= 60)
{
   System.out.println("D");
}

else
{
   System.out.println("F");
}



}





public static void main (String [] args)
{
int done = 1;

Scanner in = new Scanner (System.in);
System.out.print("Whats your CSC-115 average? ");
double myAvg = in.nextDouble();
System.out.println("You entered " + myAvg);

grader(myAvg);


while (done!=0)
{

System.out.print("Do you want to try again? 1-Yes 0-No ");
int again = in.nextInt();

if (again == 1)
{
System.out.print("Whats your CSC-115 average? ");
myAvg = in.nextDouble();
System.out.println("You entered " + myAvg);

grader(myAvg);
}

else
{
System.out.println("Goodbye!");
done--;
}

}
















}


}