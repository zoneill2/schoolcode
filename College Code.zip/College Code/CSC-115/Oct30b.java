import java.util.Scanner;

public class Oct30b
{
public static void main (String [] args)
{
Scanner in = new Scanner(System.in);
System.out.print("Do you wanna play a game? (Y/N): ");
String play = in.next();
boolean done= false;
int numba = 0;
while (!done)
{
if (play.equalsIgnoreCase("Y"))
{


System.out.print("Gimme a number: ");

while(!in.hasNextInt())
{
in.nextLine();
}


numba=in.nextInt();

System.out.print("[D]ouble or [S]quare? " );
String doThis = in.next();
while (!doThis.equalsIgnoreCase("D") && (!doThis.equalsIgnoreCase("S")))
{
System.out.print("[D]ouble or [S]quare? " );
doThis=in.next();
}

if(doThis.equalsIgnoreCase("D"))
{
System.out.println("Your number doubled is: " + (numba+numba));
}

else
{
System.out.println("Your number squared is: " +numba*numba);
}


}

else if (play.equalsIgnoreCase("N"))
{
System.out.println("Buh-bye!!!");
done=true;
}

else
{
System.out.println("Y or N, please!");
}

if (!play.equalsIgnoreCase("N"))
{
System.out.print("Do you wanna play a game? (Y/N): ");
play = in.next();
}


}//end while

} //end main
} //end class