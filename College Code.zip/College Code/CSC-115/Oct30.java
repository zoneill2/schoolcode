import java.util.Scanner;
import java.util.Random;

public class Oct30

{
   public static void main (String [] args)
   {
   Scanner in = new Scanner (System.in);
   
   String answer1;
   String answer2;
   String answer3;
   int number;
   boolean done = false;
  
   
   
   System.out.print("Do you want to play a game? Y/N ");
   answer1 = in.nextLine();
   
   while (!done)
   {
   if (answer1.equals("N"))
   {
   System.out.println("....Okay then");
   done = true;
   }
   
   else if (answer1.equals("Y"))
   {
   System.out.print("Give me a number! ");
   number = in.nextInt();
   
   System.out.print("Do you want to double or square it? D/S ");
   answer2 = in.nextLine();
  
   
   if (answer2.equals("D"))
      {
      number = (number)*2;
      System.out.println("Your number now.. " + number);
      System.out.print("Do you want to play again? Y/N");
      answer3 = in.nextLine();
      
         if (answer3.equals("Y"))
         {
         
         
         }
         
         else if (answer3.equals("N"))
         {
         System.out.println("Alright. Goodbye!");
         done = true;
         
         }
         
         else 
         {
         System.out.println("Error: Non Valid Input");
         System.out.print("Do you want to play again? Y/N");
         answer3 = in.nextLine();
         }
      }
      
   else if (answer2.equals("S"))
      {
      number = (number^2);
      System.out.println("Your number now.. " + number);
      System.out.print("Do you want to play again? Y/N");
      answer3 = in.nextLine();
      if (answer3.equals("Y"))
         {
         
         }
         
         else if (answer3.equals("N"))
         {
         System.out.println("Alright. Goodbye!");
         done = true;
         
         }
         
         else 
         {
         System.out.println("Error: Non Valid Input");
         System.out.print("Do you want to play again? Y/N");
         answer3 = in.nextLine();
         }
      }
   
   else 
      {
      System.out.println("Error: Non Valid Input");
      System.out.print("Do you want to double or square it? D/S ");
      answer2 = in.nextLine();
      }
  
   
   
   } 
   
   else
   {
   
   System.out.println("Error: Non Valid Input");
   System.out.print("Do you want to play a game? Y/N ");
   answer1 = in.nextLine();
   
   
   }
   
   
   
   }//end while
   
   


   } //end main

} //end class

  
  