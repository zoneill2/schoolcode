public class GreetingInGerman
 {
   public static void main (String [] args)
   {
   System.out.println("Hallo, wie geht es dir?");
   }

 }