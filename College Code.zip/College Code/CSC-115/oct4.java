import java.util.Scanner;


public class oct4
{
   public static void main (String [] args)
   {
   int student;
   int mood;
   int plans;
   int passing;
   
   
   Scanner in = new Scanner (System.in);
   System.out.print("Are you a CSC 115 student? (0-No 1-Yes): ");
   student = in.nextInt();
   
   if (student == 1)
   {
   
   System.out.print("Are you passing? (0-No 1-Yes): ");
   passing = in.nextInt();
      if (passing == 0)
      {
      System.out.println("See you in the spring!");
      
      }
      
      else if (passing == 1)
      {
      System.out.println("Good job!");
      }
      
      else
      {
      System.out.println("Youre dumb");
      }
   
   
   }
   
   else if (student == 0)
   {
   
   System.out.print("Are you taking it next semester? (0-No 1-Yes): ");
   plans = in.nextInt();
      if (plans == 0)
      {
      System.out.println("Why not????");
      }
   
      else if (plans == 1)
      {
      System.out.println("Cant wait!");
      
      }
      
      else
      {
      System.out.println("I can tell you dont have plans!");
      
      }
   
   else
   {
   System.out.println("I hate you");
   }
      
      
      
      
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   }


















































}



















