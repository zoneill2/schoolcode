import java.util.Scanner;


public class oct23v2
{
   public static void main (String [] args)
   {
   int number;
    
   Scanner in = new Scanner (System.in);
   boolean done = false;
   System.out.print("What is your favorite number? ");
   
   while (!done)
   {
   
      if (in.hasNextInt()  )
      {
      number = in.nextInt();
      System.out.println(number + " is my favorite number too!");
      done = true;
      }
   
      else
      {
      System.out.println("Please enter a whole number!");
      in.next();
      System.out.print("What is your favorite number? ");
      }
      


   }




















   }








}



















