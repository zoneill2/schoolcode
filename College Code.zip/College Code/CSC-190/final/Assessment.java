public interface Assessment {
    
    String getDescription();
    int getMaxPoints();
    
}