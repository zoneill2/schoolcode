public class Holy
{

   public static void main (String [] args)
   {
   int numStudents = 21;
   int numProfessors = 1;
   int totalPeeps = numStudents + numProfessors;
   System.out.println("There are " + totalPeeps + " people in the room");
   }




}