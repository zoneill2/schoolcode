
import java.util.Scanner;
public class challengeNov27
{








public static void main (String [] args)
{
int[] myNumbas = new int [10];



}

















}