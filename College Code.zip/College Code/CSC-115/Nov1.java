public class Nov1
{


public static void main (String [] args)
{
int sum=0;
int sum2=20;
int sum3=35;

for (int i=1; i<=10; i++) //
   {
  
  sum = sum + i;    
   
   
   }

System.out.println(sum);

sum=0;

for (int i=20; i<=37; i++) //
   {
  
  sum = sum + i;    
   
   
   }

System.out.println(sum);

sum=0;

for (int i=35; i<=49; i++) //
   {
  
  sum = sum + i;    
   
   
   }

System.out.println(sum);


















}


}